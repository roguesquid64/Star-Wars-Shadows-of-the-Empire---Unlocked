Star Wars - Shadows of the Empire (USA) (Rev 1) - Unlocked

This ROM Hack Unlocks All Levels in Star Wars - Shadows of the Empire (USA) (Rev 1), and adds some additional features.

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64

Details:

Unlocks All 10 Levels
Enables Debug Mode
Infinite Jetpack (Only Available in Analogue 3D & Emulator Patch)


The following Debug options are available: 

Press Z+R to Enable Debug Options, use Z or R to cycle through Options, and A to Select

Get all stuff = Enable to get all ammo types, missiles, full health, and the jetpack
Please Note: “Get all stuff” does not enable during the hover train portion of Ord Mantell Junkyard

Ammo Types: Seeker Missile, Flame Thrower, Pulse Cannon, Stunner Gun, and Disruptor

Invincibility = Enable to become invincible. Can be toggled On or Off with A.

50 Lives = Enable to get 50 lives.

Villains Are/Aren’t Sleepy = This is auto set to “Aren’t Sleepy”, so enemies will attack you. When this is set to “Are Sleepy” enemies freeze. Enemies can still be damaged while frozen and will die when they are unfrozen. Bosses such as Boba Fett won’t spawn if you have this turned on when you enter the area. Enable/Disable by pushing the Analog Stick Up or Down when “Villains Are/Aren’t Sleepy” is highlighted.

Kill Dash = Kill yourself immediately. Does not work if Invincibility is on.

Teleport = Teleports Dash to a random point of the current level. Only works with On-foot levels.

Next Level = Warps the player to the next level.

This Level = Warps the player to the start of the current level.

Prev Level = Warps the player to the previous level.

Wall Ghost = If set to ON, will disable collision for some walls, doors, ceilings, and objects. Enemies and destructible objects will still be solid, though.

Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of Star Wars - Shadows of the Empire (USA) (Rev 1) ROM with the included Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/ 

ROM / ISO Information:
Database match: Star Wars - Shadows of the Empire (USA) (Rev 1)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: DED8F972D1E1D662614B1EC79822D649A8CE5430
File/ROM CRC32: B0540688
Star Wars - Shadows of the Empire (USA) (Limited Run Games) - Unlocked

This ROM Hack Enables Debug Mode in Star Wars - Shadows of the Empire (USA) (Limited Run Games), and adds an Infinite Jetpack. 

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64 / RetroArch using Core Nintendo 64 (ParaLLEI N64)

Details:

Unlocks All 10 Levels
Enables Debug Mode
Infinite Jetpack (Only Available in Analogue 3D & Emulator Patches)


The following Debug options are available: 

Press Z+R to Enable Debug Options, use Z or R to cycle through Options, and A to Select

Get all stuff = Enable to get all ammo types, missiles, full health, and the jetpack
Please Note: “Get all stuff” does not enable during the hover train portion of Ord Mantell Junkyard

Ammo Types: Seeker Missile, Flame Thrower, Pulse Cannon, Stunner Gun, and Disruptor

Invincibility = Enable to become invincible. Can be toggled On or Off with A.

50 Lives = Enable to get 50 lives.

Villains Are/Aren’t Sleepy = This is auto set to “Aren’t Sleepy”, so enemies will attack you. When this is set to “Are Sleepy” enemies freeze. Enemies can still be damaged while frozen and will die when they are unfrozen. Bosses such as Boba Fett won’t spawn if you have this turned on when you enter the area. Enable/Disable by pushing the Analog Stick Up or Down when “Villains Are/Aren’t Sleepy” is highlighted.

Kill Dash = Kill yourself immediately. Does not work if Invincibility is on.

Teleport = Teleports Dash to a random point of the current level. Only works with On-foot levels.

Next Level = Warps the player to the next level.

This Level = Warps the player to the start of the current level.

Prev Level = Warps the player to the previous level.

Wall Ghost = If set to ON, will disable collision for some walls, doors, ceilings, and objects. Enemies and destructible objects will still be solid, though.

Jump Power = Sets the height of Dash’s jump. 1.000 is the default, but can go as low as 0.100 and as high as 3.000.

Gravity = Change the value to alter the amount of gravity. 1.000 is the default, but can go as low as 0.100 and as high as 3.000

Texture = If set to OFF, all objects will lose their textures and be shaded in grey

Lighting = If set to OFF, objects will not be affected by light

Fog = If set to OFF, will disable the distance fog and make clipping visible in the distance

Antialiasing = Can be toggled on (default) or off. Antialiasing is on by default

Screen Resolution = Does nothing. Appears to be a header for the next set of options.

vertFOV = Alters the FOV (field of view) of the camera. 77 is the default, but can go as low as 4 and as high as 120

aspect = Alters the aspect ratio of the screen. 1.33 is the default, but can go as low as 0.10 and as high as 10.00

dither = Can be toggled on (default) or off.

Fog Max = Sets the maximum view distance by altering how far back the fog starts. 200 is the default, but can go as low as 10 and as high as 999

Fog Thick = This value seems to act in reverse to Fog Max, with higher numbers making the fog “thinner” and lower values making the fog “thicker”. 996 is the default and highest value, but it can go as low as 10. Very sensitive to changes.

Fog Red = Sets the color value of the fog on the red channel. Can be set from 0 to 255, with higher numbers meaning more color and 0 being no color. 150 is the default value

Fog Green = See above. 200 is the default value.

Fog Blue = See above. 255 is the default value.

Amb Light Red = Sets the color value of the ambient light on the red channel. Can be set from 0 to 255, with higher numbers meaning more color and 0 being no color. 82 is the default value.

Amb Light Green = See above. 83 is the default value

Amb Light Blue = See above. 88 is the default value

Dir Light Red = Sets the color value of the directional light on the red channel. Can be set from 0 to 255, with higher numbers meaning more color and 0 being no color. 204 is the default value.

Dir Light Green = See above. 230 is the default value

Dir Light Blue = See above. 241 is the default value

Dir Light Ve = Alters the direction of the lighting used on objects with the values representing the x-axis of rotation, the y-axis, and z axis. The default is -62 -54 86, but it is incredibly sensitive, with almost no chance of obtaining a desired result on any or all of the values. Use the Control Stick to alter the value. Please Note: This option freezes on N64 and A3D. 

Revert Fog and Lights = Resets all light and fog values back to their defaults. Does not change any other values like gravity or jump height

Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of Star Wars - Shadows of the Empire (USA) (Limited Run Games) ROM with the included Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/ 

ROM / ISO Information:
Database match: Star Wars - Shadows of the Empire (USA) (Limited Run Games)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: 6932F8B10A5DE27500521DE50D04E3BA097DD9D9
File/ROM CRC32: 776A069B
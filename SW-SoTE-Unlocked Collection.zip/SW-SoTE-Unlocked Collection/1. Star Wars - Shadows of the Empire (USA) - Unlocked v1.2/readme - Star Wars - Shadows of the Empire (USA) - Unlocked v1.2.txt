Star Wars - Shadows of the Empire (USA) - Unlocked v1.2

This ROM Hack Unlocks Everything in Star Wars - Shadows of the Empire (USA), and adds some additional features.

Compatibility Confirmed on Everdrive64-X7 / N64 Console / Analogue 3D / Simple64

Details:

Unlocks All 10 Levels
Unlocks All 87 Challenge Points (Save Slot 1 Only)
Enables Debug Mode
Infinite Tow Cables
Infinite Jetpack (Only Available in Analogue 3D & Emulator Patch)

Unlocks All 87 Challenge Points (Save Slot 1 Only) Details:
Regardless of how many Challenge Points you collect during a level, you will always be rewarded with the maximum amount after you; Press Start to Update Player Data. Once you beat the game an extra option titled: “Game Secrets” will be available from the Pause Menu. Selecting this will show what extra options you have unlocked for either Easy, Medium, Hard, or Jedi. The final level: Skyhook Battle, does not have any Challenge Points to unlock. 

Challenge Point Rewards: 
Complete the game on Easy to unlock Leebo Scanner: 
While on foot, hold down the camera button (C Right) for five seconds to change to a birds eye view that reveals Enemies, Ammo, Health, and Challenge Points. 
(Easy only has access to Leebo Scanner)

Complete the game on Medium to unlock X-Wing and TIE Fighter: 
These two ships are only accessible on the second portion of the final level. While at the Skyhook Station, hold down the camera button (C Right) for five seconds to take control of an X-Wing. Hold the camera button down for another 5 seconds to take control of a TIE Fighter. 
(Medium also has access to Leebo Scanner)

Complete the game on Hard to unlock All Ammo Types and Temporarily Invincible:
Hold C Down for 15 Seconds and you will be temporarily invincible and have all ammo types. 
(Hard also has access to Leebo Scanner and X-Wing / TIE Fighter)

Complete the game on Jedi to unlock friendly Wampas:
Wampas will follow you around and not attack you. 
(Jedi also has access to Leebo Scanner, X-Wing / TIE Fighter, and Temp Invincibility / Ammo)



The following Debug options are available: 

Press Z+R to Enable Debug Options, use Z or R to cycle through Options, and A to Select

Get all stuff = Enable to get all ammo types, missiles, full health, and the jetpack
Please Note: “Get all stuff” does not enable during the hover train portion of Ord Mantell Junkyard

Ammo Types: Seeker Missile, Flame Thrower, Pulse Cannon, Stunner Gun, and Disruptor

Invincibility = Enable to become invincible. Can be toggled On or Off with A.

50 Lives = Enable to get 50 lives.

Villains Are/Aren’t Sleepy = This is auto set to “Aren’t Sleepy”, so enemies will attack you. When this is set to “Are Sleepy” enemies freeze. Enemies can still be damaged while frozen and will die when they are unfrozen. Bosses such as Boba Fett won’t spawn if you have this turned on when you enter the area. Enable/Disable by pushing the Analog Stick Up or Down when “Villains Are/Aren’t Sleepy” is highlighted.

Kill Dash = Kill yourself immediately. Does not work if Invincibility is on.

Teleport = Teleports Dash to a random point of the current level. Only works with On-foot levels.

Next Level = Warps the player to the next level.

This Level = Warps the player to the start of the current level.

Prev Level = Warps the player to the previous level.

Wall Ghost = If set to ON, will disable collision for some walls, doors, ceilings, and objects. Enemies and destructible objects will still be solid, though.

Upload a copy of your ROM to confirm you have the correct version for this patch via the following link: https://www.romhacking.net/hash/

Convert your ROM from .n64/.v64 to the required format of .z64 via the following link: https://hack64.net/tools/swapper.php

Patch your copy of Star Wars - Shadows of the Empire (USA) ROM with the included Floating IPS File (.bps) via the following link: https://www.romhacking.net/patch/ 

ROM / ISO Information:
Database match: Star Wars - Shadows of the Empire (USA)
Database: No-Intro: Nintendo 64 (v. 20210220-053642)
File/ROM SHA-1: 271C285F6E5069133AB27A2A8324D4651591E35D
File/ROM CRC32: 3C0837B3